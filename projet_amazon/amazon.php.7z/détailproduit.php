<?php

$produits = array(
    array(
        "id" => 1,
        "name" => "Produit 1",
        "overview" => "lorem picsum le chien",
        "image" => "https://picsum.photos/id/237/200/300",
        "price" => 99.99
    ), array(
        "id" => 2,
        "name" => "Produit 2",
        "overview" => "lorem picsum maison",
        "image" => "https://picsum.photos/id/236/200/300",
        "price" => 99.99
    ), array(
        "id" => 3,
        "name" => " LE CRI (the cat's scream) ",
        "overview" => " MUNCH ",
        "image" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTM20mcTA1zwdIxzyL2dkt5A8Ae7Q94Y9QV1KdT4pa-RYf8q-7lffCYYEua1rLIJOE7o2c&usqp=CAU",
        "price" => 99.99,
    ), array(
        "id" => 4,
        "name" => "Produit 4",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" => "https://www.amazon.com/images.jpeg",
        "price" => 99.99
    ), array(
        "id" => 5,
        "name" => "Produit 5",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" => "https://www.amazon.com/images.jpeg",
        "price" => 99.99
    )
);



/*$choix= $_get['choix']??0;
$test="produits" [$choix]['name'];*/




































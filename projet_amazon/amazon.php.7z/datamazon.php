<?php

$produits = array(
    array(
        "id" => 1,
        "name" => "La rue la maison jaune tableau de Van gogh",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" =>"img/la rue la maison jaune",
        "price" => 250.99
    ), array(
        "id" => 2,
        "name" => "La nuit étoile tableau de Van gogh",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" => "img/van-gog-la-nuit-etoilée.jpg",
        "price" => 880.45,
    ), array(
        "id" => 3,
        "name" => "LE CRI (the cat's scream)",
        "overview" => "MUNCH",
        "image" => "img/tableauchat.jpg",
        "price" => 99.99,
    ), array(
        "id" => 4,
        "name" => "Skull tableau de Van gogh",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" => "img/van gogh skull.jpg",
        "price" => 700.60,
    ), array(
        "id" => 5,
        "name" => "Vu de Montmartre Tableau de van gogh",
        "overview" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "image" => "img/van-gog-vue-de-montmartre.jpg",
        "price" => 850.85,
    ),

);

?>